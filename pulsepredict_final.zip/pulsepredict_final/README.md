# PulsePredict FINAL

## Includes
- Mobile public dashboard
- Today's published predictions
- Timestamped prediction records in Supabase
- Sportmonks fixtures, xG and prediction feed
- Automatic post-match settlement
- Public hit-rate calculation
- Stripe subscription checkout foundation
- PayPal subscription webhook foundation
- Vercel scheduled jobs

## Environment variables
SPORTMONKS_TOKEN=\nSUPABASE_URL=\nSUPABASE_SERVICE_ROLE_KEY=\nCRON_SECRET=\nAPP_URL=https://your-domain\nSTRIPE_SECRET_KEY=\nSTRIPE_PRICE_ID=\nSTRIPE_WEBHOOK_SECRET=\nPAYPAL_CLIENT_ID=\nPAYPAL_CLIENT_SECRET=\nPAYPAL_WEBHOOK_ID=

## Deploy
1. Run supabase/schema.sql in Supabase SQL Editor.
2. Upload this folder to GitHub.
3. Import the repo into Vercel.
4. Add the environment variables.
5. Deploy.
6. Configure Stripe webhook at /api/stripe-webhook.
7. Configure PayPal webhook at /api/paypal-webhook.

Before accepting real customers, add authenticated customer accounts, verified PayPal webhook signatures, payment-to-user mapping, rate limits, retries, monitoring, backups, and final legal/privacy/gambling compliance review.
